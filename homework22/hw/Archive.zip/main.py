import find_elems
import requests

url = "https://getpocket.com/explore/item/a-simple-formula-for-changing-our-behavior?utm_source=pocket-newtab"
headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu 21.10; Linux x86_64; rv:92.0) Gecko/20100101 Firefox/69.0'} # This tricks the server into thinking that we're using Ubuntu 21.04 and Firefox 69.0.
r = requests.get(url, headers=headers)


